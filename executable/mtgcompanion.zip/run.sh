java -jar -Xmx1024m mtgcompanion.jar
